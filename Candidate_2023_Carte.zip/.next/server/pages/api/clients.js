"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/clients";
exports.ids = ["pages/api/clients"];
exports.modules = {

/***/ "@faker-js/faker":
/*!**********************************!*\
  !*** external "@faker-js/faker" ***!
  \**********************************/
/***/ ((module) => {

module.exports = import("@faker-js/faker");;

/***/ }),

/***/ "(api)/./src/pages/api/clients.ts":
/*!**********************************!*\
  !*** ./src/pages/api/clients.ts ***!
  \**********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _faker_js_faker__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @faker-js/faker */ \"@faker-js/faker\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_faker_js_faker__WEBPACK_IMPORTED_MODULE_0__]);\n_faker_js_faker__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nconst createRandomClient = ()=>{\n    const sex = _faker_js_faker__WEBPACK_IMPORTED_MODULE_0__.faker.name.sexType();\n    //Get firstName which is matching to sex\n    const firstName = _faker_js_faker__WEBPACK_IMPORTED_MODULE_0__.faker.name.firstName(sex);\n    const lastName = _faker_js_faker__WEBPACK_IMPORTED_MODULE_0__.faker.name.lastName();\n    //Get email which is matching to firstName and lastName\n    const email = _faker_js_faker__WEBPACK_IMPORTED_MODULE_0__.faker.internet.email(firstName, lastName);\n    return {\n        id: _faker_js_faker__WEBPACK_IMPORTED_MODULE_0__.faker.datatype.uuid(),\n        avatar: _faker_js_faker__WEBPACK_IMPORTED_MODULE_0__.faker.image.avatar(),\n        birthday: _faker_js_faker__WEBPACK_IMPORTED_MODULE_0__.faker.date.birthdate(),\n        email,\n        firstName,\n        lastName,\n        sex,\n        supportTier: _faker_js_faker__WEBPACK_IMPORTED_MODULE_0__.faker.helpers.arrayElement([\n            \"standard\",\n            \"gold\",\n            \"platinum\"\n        ]),\n        hourlyRate: _faker_js_faker__WEBPACK_IMPORTED_MODULE_0__.faker.helpers.arrayElement([\n            60,\n            75,\n            100,\n            125\n        ])\n    };\n};\nfunction handler(req, res) {\n    switch(req.method){\n        case \"GET\":\n            const clients = [\n                ...Array.from(Array(20)).map(()=>createRandomClient())\n            ];\n            res.status(200).json({\n                clients\n            });\n            break;\n        case \"POST\":\n            break;\n        default:\n            res.status(400).json({\n                error: \"Bad request type\"\n            });\n    }\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvcGFnZXMvYXBpL2NsaWVudHMudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFDd0M7QUFFeEMsTUFBTUMscUJBQXFCLElBQU07SUFDN0IsTUFBTUMsTUFBTUYsK0RBQWtCO0lBQzlCLHdDQUF3QztJQUN4QyxNQUFNSyxZQUFZTCxpRUFBb0IsQ0FBQ0U7SUFDdkMsTUFBTUksV0FBV04sZ0VBQW1CO0lBQ3BDLHVEQUF1RDtJQUN2RCxNQUFNTyxRQUFRUCxpRUFBb0IsQ0FBQ0ssV0FBV0M7SUFFOUMsT0FBTztRQUNIRyxJQUFJVCxnRUFBbUI7UUFDdkJZLFFBQVFaLCtEQUFrQjtRQUMxQmMsVUFBVWQsaUVBQW9CO1FBQzlCTztRQUNBRjtRQUNBQztRQUNBSjtRQUNBZSxhQUFhakIsdUVBQTBCLENBQUM7WUFDcEM7WUFDQTtZQUNBO1NBQ0g7UUFDRG9CLFlBQVlwQix1RUFBMEIsQ0FBQztZQUFDO1lBQUk7WUFBSTtZQUFLO1NBQUk7SUFDN0Q7QUFDSjtBQUVlLFNBQVNxQixRQUFRQyxHQUFtQixFQUFFQyxHQUFvQixFQUFFO0lBQ3ZFLE9BQVFELElBQUlFLE1BQU07UUFDZCxLQUFLO1lBQ0QsTUFBTUMsVUFBVTttQkFDVEMsTUFBTUMsSUFBSSxDQUFDRCxNQUFNLEtBQUtFLEdBQUcsQ0FBQyxJQUFNM0I7YUFDdEM7WUFDRHNCLElBQUlNLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7Z0JBQUVMO1lBQVE7WUFDL0IsS0FBTTtRQUNWLEtBQUs7WUFDRCxLQUFNO1FBQ1Y7WUFDSUYsSUFBSU0sTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztnQkFBRUMsT0FBTztZQUFtQjtJQUN6RDtBQUNKLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0Ly4vc3JjL3BhZ2VzL2FwaS9jbGllbnRzLnRzP2M5ZGYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmV4dEFwaVJlcXVlc3QsIE5leHRBcGlSZXNwb25zZSB9IGZyb20gJ25leHQnO1xuaW1wb3J0IHsgZmFrZXIgfSBmcm9tICdAZmFrZXItanMvZmFrZXInO1xuXG5jb25zdCBjcmVhdGVSYW5kb21DbGllbnQgPSAoKSA9PiB7XG4gICAgY29uc3Qgc2V4ID0gZmFrZXIubmFtZS5zZXhUeXBlKCk7XG4gICAgLy9HZXQgZmlyc3ROYW1lIHdoaWNoIGlzIG1hdGNoaW5nIHRvIHNleFxuICAgIGNvbnN0IGZpcnN0TmFtZSA9IGZha2VyLm5hbWUuZmlyc3ROYW1lKHNleCk7XG4gICAgY29uc3QgbGFzdE5hbWUgPSBmYWtlci5uYW1lLmxhc3ROYW1lKCk7XG4gICAgLy9HZXQgZW1haWwgd2hpY2ggaXMgbWF0Y2hpbmcgdG8gZmlyc3ROYW1lIGFuZCBsYXN0TmFtZVxuICAgIGNvbnN0IGVtYWlsID0gZmFrZXIuaW50ZXJuZXQuZW1haWwoZmlyc3ROYW1lLCBsYXN0TmFtZSk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgICBpZDogZmFrZXIuZGF0YXR5cGUudXVpZCgpLFxuICAgICAgICBhdmF0YXI6IGZha2VyLmltYWdlLmF2YXRhcigpLFxuICAgICAgICBiaXJ0aGRheTogZmFrZXIuZGF0ZS5iaXJ0aGRhdGUoKSxcbiAgICAgICAgZW1haWwsXG4gICAgICAgIGZpcnN0TmFtZSxcbiAgICAgICAgbGFzdE5hbWUsXG4gICAgICAgIHNleCxcbiAgICAgICAgc3VwcG9ydFRpZXI6IGZha2VyLmhlbHBlcnMuYXJyYXlFbGVtZW50KFtcbiAgICAgICAgICAgICdzdGFuZGFyZCcsXG4gICAgICAgICAgICAnZ29sZCcsXG4gICAgICAgICAgICAncGxhdGludW0nLFxuICAgICAgICBdKSxcbiAgICAgICAgaG91cmx5UmF0ZTogZmFrZXIuaGVscGVycy5hcnJheUVsZW1lbnQoWzYwLCA3NSwgMTAwLCAxMjVdKSxcbiAgICB9O1xufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaGFuZGxlcihyZXE6IE5leHRBcGlSZXF1ZXN0LCByZXM6IE5leHRBcGlSZXNwb25zZSkge1xuICAgIHN3aXRjaCAocmVxLm1ldGhvZCkge1xuICAgICAgICBjYXNlICdHRVQnOlxuICAgICAgICAgICAgY29uc3QgY2xpZW50cyA9IFtcbiAgICAgICAgICAgICAgICAuLi5BcnJheS5mcm9tKEFycmF5KDIwKSkubWFwKCgpID0+IGNyZWF0ZVJhbmRvbUNsaWVudCgpKSxcbiAgICAgICAgICAgIF07XG4gICAgICAgICAgICByZXMuc3RhdHVzKDIwMCkuanNvbih7IGNsaWVudHMgfSk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnUE9TVCc6XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHJlcy5zdGF0dXMoNDAwKS5qc29uKHsgZXJyb3I6ICdCYWQgcmVxdWVzdCB0eXBlJyB9KTtcbiAgICB9XG59XG4iXSwibmFtZXMiOlsiZmFrZXIiLCJjcmVhdGVSYW5kb21DbGllbnQiLCJzZXgiLCJuYW1lIiwic2V4VHlwZSIsImZpcnN0TmFtZSIsImxhc3ROYW1lIiwiZW1haWwiLCJpbnRlcm5ldCIsImlkIiwiZGF0YXR5cGUiLCJ1dWlkIiwiYXZhdGFyIiwiaW1hZ2UiLCJiaXJ0aGRheSIsImRhdGUiLCJiaXJ0aGRhdGUiLCJzdXBwb3J0VGllciIsImhlbHBlcnMiLCJhcnJheUVsZW1lbnQiLCJob3VybHlSYXRlIiwiaGFuZGxlciIsInJlcSIsInJlcyIsIm1ldGhvZCIsImNsaWVudHMiLCJBcnJheSIsImZyb20iLCJtYXAiLCJzdGF0dXMiLCJqc29uIiwiZXJyb3IiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./src/pages/api/clients.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./src/pages/api/clients.ts"));
module.exports = __webpack_exports__;

})();